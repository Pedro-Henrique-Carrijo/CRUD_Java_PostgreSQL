package br.com.pedro.crud;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ProdutoDAO produtoDAO = new ProdutoDAO();

    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("\n===== CRUD PRODUTOS =====");
            System.out.println("1 - Cadastrar produto");
            System.out.println("2 - Listar produtos");
            System.out.println("3 - Atualizar produto");
            System.out.println("4 - Excluir produto");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");

            opcao = lerInteiro();

            try {
                switch (opcao) {
                    case 1 -> cadastrar();
                    case 2 -> listar();
                    case 3 -> atualizar();
                    case 4 -> excluir();
                    case 0 -> System.out.println("Encerrando...");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (SQLException e) {
                System.out.println("Erro ao acessar o banco: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Valor inválido: " + e.getMessage());
            }
        } while (opcao != 0);

        scanner.close();
    }

    private static void cadastrar() throws SQLException {
        System.out.print("Nome: ");
        String nome = scanner.nextLine().trim();
        if (nome.isEmpty()) {
            throw new IllegalArgumentException("O nome é obrigatório.");
        }

        System.out.print("Descrição: ");
        String descricao = scanner.nextLine().trim();

        System.out.print("Preço: ");
        BigDecimal preco = lerDecimal();

        System.out.print("Quantidade: ");
        int quantidade = lerInteiro();

        validarValores(preco, quantidade);
        produtoDAO.cadastrar(new Produto(nome, descricao, preco, quantidade));
        System.out.println("Produto cadastrado com sucesso.");
    }

    private static void listar() throws SQLException {
        List<Produto> produtos = produtoDAO.listar();

        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        for (Produto produto : produtos) {
            System.out.println("\nID: " + produto.getId());
            System.out.println("Nome: " + produto.getNome());
            System.out.println("Descrição: " + produto.getDescricao());
            System.out.println("Preço: R$ " + produto.getPreco());
            System.out.println("Quantidade: " + produto.getQuantidade());
        }
    }

    private static void atualizar() throws SQLException {
        System.out.print("ID do produto: ");
        long id = lerLong();

        System.out.print("Novo nome: ");
        String nome = scanner.nextLine().trim();
        if (nome.isEmpty()) {
            throw new IllegalArgumentException("O nome é obrigatório.");
        }

        System.out.print("Nova descrição: ");
        String descricao = scanner.nextLine().trim();

        System.out.print("Novo preço: ");
        BigDecimal preco = lerDecimal();

        System.out.print("Nova quantidade: ");
        int quantidade = lerInteiro();

        validarValores(preco, quantidade);
        boolean atualizado = produtoDAO.atualizar(new Produto(id, nome, descricao, preco, quantidade));
        System.out.println(atualizado ? "Produto atualizado com sucesso." : "Produto não encontrado.");
    }

    private static void excluir() throws SQLException {
        System.out.print("ID do produto: ");
        long id = lerLong();

        boolean excluido = produtoDAO.excluir(id);
        System.out.println(excluido ? "Produto excluído com sucesso." : "Produto não encontrado.");
    }

    private static void validarValores(BigDecimal preco, int quantidade) {
        if (preco.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("O preço não pode ser negativo.");
        }
        if (quantidade < 0) {
            throw new IllegalArgumentException("A quantidade não pode ser negativa.");
        }
    }

    private static int lerInteiro() {
        try {
            int valor = Integer.parseInt(scanner.nextLine().trim());
            return valor;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Digite um número inteiro.");
        }
    }

    private static long lerLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Digite um ID válido.");
        }
    }

    private static BigDecimal lerDecimal() {
        try {
            return new BigDecimal(scanner.nextLine().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Digite um preço válido, por exemplo 19,90.");
        }
    }
}
