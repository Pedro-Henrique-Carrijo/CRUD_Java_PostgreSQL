package br.com.pedro.crud;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Conexao {
    public static Connection conectar() throws SQLException {
        Properties propriedades = new Properties();

        try (InputStream entrada = Conexao.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (entrada == null) {
                throw new SQLException("Arquivo db.properties não encontrado.");
            }
            propriedades.load(entrada);
        } catch (IOException e) {
            throw new SQLException("Não foi possível ler as configurações do banco.", e);
        }

        String url = propriedades.getProperty("db.url");
        String usuario = propriedades.getProperty("db.user");
        String senha = propriedades.getProperty("db.password");

        if (senha == null || senha.isBlank() || senha.equals("COLOQUE_SUA_SENHA_AQUI")) {
            throw new SQLException("Configure a senha do PostgreSQL em db.properties.");
        }

        return DriverManager.getConnection(url, usuario, senha);
    }
}
